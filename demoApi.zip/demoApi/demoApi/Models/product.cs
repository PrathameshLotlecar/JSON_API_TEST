﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace demoApi.Models
{
    public class product
    {
        public int productid { get; set; }
        public string productname { get; set; }
        public decimal price { get; set; }
        public int qty { get; set; }
    }
}