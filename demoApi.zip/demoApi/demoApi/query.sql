create database demoapi;
use demoapi;
create table products
(
productid int primary key identity(1,1),
productname varchar(50),
price decimal(10,2),
qty int
);

insert into products values ('Biscuit',50,100),('Chips',30,500),('Water',20,900),('Frooti',15,800),('Cola',25,200);
select * from products;
