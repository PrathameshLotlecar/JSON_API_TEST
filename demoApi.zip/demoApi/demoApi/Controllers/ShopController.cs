﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using demoApi.Models;
using Newtonsoft.Json;

namespace demoApi.Controllers
{
    public class ShopController : ApiController
    {
        [HttpGet]
        public HttpResponseMessage GetProducts()
        {
            string cs = ConfigurationManager.ConnectionStrings["demoapiCS"].ConnectionString;
            SqlConnection con = new SqlConnection(cs);
            DataSet ds = new DataSet();
            string qry = "select * from products;";
            SqlCommand cmd = new SqlCommand(qry, con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            con.Open();
            sda.Fill(ds, "products");
            con.Close();
            List<product> products = new List<product>();
            bool te;
            if (ds.Tables.Contains("products"))
                te = true;

            foreach (DataRow dr in ds.Tables["products"].Rows)
            {
                product p = new product();
                p.productid = Convert.ToInt32(dr["productid"]);
                p.productname = dr["productid"].ToString();
                p.price = Convert.ToDecimal(dr["price"]);
                p.qty = Convert.ToInt32(dr["qty"]);
                products.Add(p);
            }
            var json = JsonConvert.SerializeObject(new
            {
                prods = products
            });
            var response = Request.CreateResponse(HttpStatusCode.OK);
            response.Content = new StringContent(json.ToString(), Encoding.UTF8, "application/json");
            return response;
            //return new HttpResponseMessage(HttpStatusCode.OK);
        } 
    }
}
